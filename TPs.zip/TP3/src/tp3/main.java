package tp3;

public class main {

	public static void main(String[] args) {
		
		ColaPrioridadAO cola = new ColaPrioridadAO(); // OBJETO COLA
		System.out.println("Cola creada.");
		
		cola.inicializarCola(); // INICIALIZACION COLA
		cola.acolarPrioridad(5, 1); // DATOS (ELEMENTO INGRESADO EN COLA)
		cola.acolarPrioridad(3, 7); // DATOS (ELEMENTO INGRESADO EN COLA)
		cola.acolarPrioridad(10, 2); // DATOS (ELEMENTO INGRESADO EN COLA)
		System.out.println("Elementos agregados en cola.");
		
		System.out.println("Incio procesos.");
		while (!cola.colaVacia()) { // MIENTRAS LA COLA NO ESTE VACIA
			int valorActual = cola.primero(); // VALOR PRIMER ELEMENTO
			int prioridadActual = cola.prioridad(); // PRIORIDAD PRIMER ELEMENTO
			System.out.println("[Valor elemento: " + valorActual + ", Prioridad elemento: " + prioridadActual + "]");
			cola.desacolar(); // ELIMINO ESE ELEMENTO
		}
		
		System.out.println("Elementos elminados de la cola.");
		
	}
	
}
