package tp3;

public interface ColaPrioridadTDA {
	
	void inicializarCola();
	void acolarPrioridad(int x, int prioridad);
	void desacolar();
	int primero();
	boolean colaVacia();
	int prioridad();
	
}
