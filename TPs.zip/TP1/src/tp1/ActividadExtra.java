package tp1;

public class ActividadExtra {

	public static void main(String[] args) {
		
		int numero = 25;
		
		if (numero > 0) {
			System.out.println("Número positivo.");
		}
		else if (numero < 0) {
			System.out.println("Número negativo.");
		}
		else {
			System.out.println("Cero.");
		}
		
		for (int i = 1; i <= numero; i++) {
			System.out.println(i);
		}
		
		if (numero % 2 == 0) {
			System.out.println("Número par.");
		}
		else {
			System.out.println("Número impar.");
		}
		

	}

}
