package tp1;

public class ActividadPracticaIntegradora {

	public static void main(String[] args) {
		
		// 1. Declarar variables para nombre, edad y nota.
		
		String nombre = "Juan Martin";
		int edad = 19;
		float nota = 10;
		
		// 2. Mostrar si la nota está aprobada o desaprobada.
		
		if (nota >= 4) {
			System.out.println("Aprobado.");
		}
		else {
			System.out.println("Desaprobado.");
		}
		
		// 3. Mostrar si la edad corresponde a mayor o menor de edad.
		
		if (edad >= 18) {
			System.out.println("Mayor de edad.");
		}
		else {
			System.out.println("Menor de edad.");
		}
		
		// 4. Mostrar los números del 1 al 10 con for.
		
		for (int i = 1; i <= 10; i++) {
			System.out.println(i);
		}
		
		// 5. Mostrar los números pares del 2 al 20.
		
		for (int i = 2; i <= 20; i = i + 2) {
			System.out.println(i);
		}
		
		// 6. Dado un número del 1 al 3, mostrar un turno usando switch.
		
		int turno = 2;
		
		switch (turno) {
			case 1:
				System.out.println("Mañana");
				break;
			case 2:
				System.out.println("Tarde");
				break;
			case 3:
				System.out.println("Noche");
				break;
			default:
				System.out.println("Turno no válido");
		}
		

	}

}
