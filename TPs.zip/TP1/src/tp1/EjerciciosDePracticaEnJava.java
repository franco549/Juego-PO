package tp1;

public class EjerciciosDePracticaEnJava {

	public static void main(String[] args) {

		// 1. DECLARACION DE VARIABLES
		
				int edad;
				char apellido;
				boolean aprobado;
				float precio;
				
				// 2. DECLARACION Y ASIGNACION
				
				int contador = 0;
				char letra = 'A';
				boolean activo = true;
				
				// 3. CORRECCION DE ERRORES DE TIPOS
				
				int numero = 5;
				char inicial = 'M';
				boolean estado = true;
				
				// 4. OPERADORES ARITMETICOS
				
				int x = 10;
				int y = 3;
				
				int suma = x + y;
				int resta = x - y;
				int multiplicacion = x * y;
				float division = x / y;
				int modulo = x % y;
				
				// 5. INCREMENTO Y DECREMENTO
				
				int xB = 5;
				
				int incremento = xB++; // xB = 6;
				int decremento = xB--; // xB = 4;
				
				// 6. OPERADORES RELACIONALES
				
				int a = 4;
				int b = 7;
				boolean booleano1 = a < b; // valor true
				boolean booleano2 = a > b; // valor false
				boolean booleano3 = a == b; // valor false
				boolean booleano4 = a != b; // valor true
				boolean booleano5 = a <= 4; // valor true
				
				// 7. OPERADORES LOGICOS I
				
				int edadB = 20;
				boolean tieneEntrada = true;
				boolean booleanoA = edadB >= 18 && tieneEntrada; // valor true
				
				// 8. OPERADORES LOGICOS II
				
				int nota = 3;
				boolean recupera = true;
				boolean booleanoB = nota >= 4 || recupera; // valor true
				
				// 9. OPERADOR DE NEGACION
				
				boolean activoB = false;
				boolean invActivoB = !activoB; // valor true
				
				// 10. CONDICIONAL SIMPLE
				
				int numeroB = 10;
				
				if (numeroB % 2 == 0) {
					System.out.println("Es par");
				}
				
				// 11. CONDICIONAL DOBLE
				
				int numeroC = 11;
				
				if (numeroC % 2 == 0) {
					System.out.println("Es par");
				} else {
					System.out.println("Es impar");
				}
				
				// 12. CONDICIONAL MULTIPLE
				
				int numeroD = 0;
				
				if (numeroD % 2 == 0) {
					System.out.println("Es par");
				} else if (numeroD % 2 != 0){
					System.out.println("Es impar");
				} else {
					System.out.println("Es cero");
				}
				
				// 13. SWITCH BASICO
				
				int numeroE = 2;
				
				switch (numeroE) {
					case 1:
						System.out.println("Mañana");
						break;
					case 2:
						System.out.println("Tarde");
						break;
					case 3:
						System.out.println("Noche");
						break;
					default:
						System.out.println("Turno inválido");
				}
				
				// 14. ELEGIR ESTRUCTURA DE CONTROL
				
				// Situación: Dado un número del 1 al 12, mostrar el mes correspondiente.
				// LO MAS CONVENIENTE ES UTILIZAR SWITCH, POR LA PROLIJIDAD Y ORGANIZACIÓN VISUAL.
				
				// 15. CICLO FOR I
				
				for (int i = 1; i <= 5; i++) {
					System.out.println(i);
				}
				
				// 16. CICLO FOR II
				
				for (int i = 10; i >= 1; i--) {
					System.out.println(i);
				}
				
				// 17. CICLO FOR III
				
				int sumaB = 0;
				
				for (int i = 1; i <= 10; i++) {
					sumaB = sumaB + i;
				}
				
				// 18. CICLO WHILE I
				
				int j = 0;
				
				while (j <= 5) {
					j = j++;
					System.out.println(j);
				}
				
				// 19. CICLO WHILE 2
				
				int k = 0;
				int sumaC = 0;
				
				while (k <= 10) {
					k = k++;
					sumaC = sumaC + k;
					System.out.println(sumaC);
				}
				
				// 20. CICLO DO WHILE I
				
				int contadorB = 1;
		        
		        do {
		            System.out.println(contadorB);
		            contadorB++;
		        } while (contadorB <= 5);
				
		        // 21. CICLO DO WHILE II
		        
		        int numeroF = 10;
		        
		        do {
		            System.out.println("Condición correcta, o primer recorrido");
		            numeroF++;
		        } while (numeroF < 5);
		        
		        // 22. IDENTIFICAR QUE USAR
		        
		        /*
		        1. Mostrar “Aprobado” solo si la nota es mayor o igual a 4.
		        	CONVENIENTE ESTRUCTURA IF

		        2. Mostrar si un número es par o impar.
		        	CONVENIENTE ESTRUCTURA IF/ELSE

		        3. Mostrar el nombre del día según un número del 1 al 7.
		        	CONVENIENTE ESTRUCTURA SWITCH

		        4. Imprimir los números del 1 al 100.
		        	CONVENIENTE ESTRUCTURA FOR

		        5. Repetir una acción mientras el usuario no ingrese 0.
		        	CONVENIENTE ESTRUCTURA WHILE

		        6. Mostrar un menú al menos una vez.
		        	CONVENIENTE ESTRUCTURA DO WHILE
		        */
	}

}
