package tp1;

public class ActividadDeAnalisis {

	public static void main(String[] args) {
		
		/*
		1. Ejecutar una acción solo si una condición es verdadera.
			IF, DEBIDO A QUE SOLO INTERESA CUANDO ES VERDADERO.
		
		2. Elegir entre dos caminos posibles.
			IF/ELSE, NOS INTERESAN AMBOS CAMINOS.
			
		3. Elegir entre varios valores posibles de una misma variable.
			SWITCH, DEBIDO A ORGANIZACION VISUAL, AL SER VARIAS OPCIONES.
			
		4. Repetir una acción una cantidad conocida de veces.
			FOR, SE PARAMETRIZA LA CANTIDAD FIJA DE ITERACIONES.
			
		5. Repetir una acción mientras se cumpla una condición.
			WHILE, SE PARAMETRIZA CON CONDICIONES, Y NO CON CANTIDAD DE ITERACIONES FIJAS.
		
		6. Ejecutar un bloque al menos una vez antes de evaluar la condición.
			DO WHILE, ES SU FUNCION COMO ESTRUCTURA.
		
		*/
	}

}
