package colaConPrioridad;

public class ColaConPrioridad implements IColaConPrioridad{
	
	private class Elemento {
		int valor;
		int prioridad;
		
		Elemento(int valor, int prioridad) {
			this.valor = valor;
			this.prioridad = prioridad;
		}
	}
	
	private Elemento[] cola;
	private int cantidad;
	
	public ColaConPrioridad(int capacidad) {
		this.cola = new Elemento[capacidad];
		this.cantidad = 0;
	}
	
	public void encolar(int valor, int prioridad) {
		if (cantidad < cola.length) {
			Elemento nuevo = new Elemento(valor, prioridad);
			int i = cantidad;
			while (i > 0 && cola[i - 1].prioridad > prioridad) {
				cola[i] = cola[i - 1];
				i--;
			}
			cola[i] = nuevo;
			cantidad++;
		} else {
			System.out.println("ERROR: Cola llena. No se encoló el valor " + valor);
		}
	}
	
	public int desencolar() {
		int valorRetorno = -1;
		if (!estaVacia()) {
			valorRetorno = cola[0].valor;
			for (int i = 0; i < cantidad - 1; i++) {
				cola[i] = cola[i + 1];
			}
			cantidad--;
		} else {
			System.out.println("ERROR: La cola está vacía.");
		}
		return valorRetorno;
	}
	
	public void mostrarContenido() {
		System.out.print("Estado de la Cola -> ");
		for (int i = 0; i < cantidad; i++) {
			System.out.print("[" + cola[i].valor + "(P:" + cola[i].prioridad + ")] ");
		}
		System.out.println();
	}
	
	public boolean estaVacia() {
		return cantidad == 0;
	}
}
