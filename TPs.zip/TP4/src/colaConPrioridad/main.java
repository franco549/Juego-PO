package colaConPrioridad;

public class main {

	public static void main(String[] args) {
		
		System.out.println("--- COLA DE PRIORIDAD ---");
		IColaConPrioridad cola = new ColaConPrioridad(5);
		
		System.out.println("\n[PRUEBA 1 y 2] Inserción y Regla FIFO:");
		cola.encolar(100, 3);
		cola.encolar(200, 1);
		cola.encolar(300, 2);
		cola.encolar(400, 1);
		cola.encolar(500, 5);
		cola.mostrarContenido();
		
		System.out.println("\n[PRUEBA 3] Validación de Desbordamiento:");
		cola.encolar(999, 1);
		cola.mostrarContenido();
		
		System.out.println("\n[PRUEBA 4] Reset de Cola (Desencolado Secuencial):");
		while ( !cola.estaVacia()) {
			int transaccion = cola.desencolar();
			System.out.println("Elimiando elemento de valor: " + transaccion);
		}
		
		System.out.println("\n[PRUEBA 5] Validación de Agotamiento:");
		int datoVacio = cola.desencolar();
		
		System.out.println("\nFin. " + datoVacio);

	}

}
