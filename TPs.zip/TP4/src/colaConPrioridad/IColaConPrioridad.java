package colaConPrioridad;

public interface IColaConPrioridad {
	void encolar(int valor, int prioridad);
	int desencolar();
	void mostrarContenido();
	boolean estaVacia();
}
