package atencionDePacientes;

public class main {

	public static void main(String[] args) {
		System.out.println("INICIANDO SISTEMA DE GESTIÓN HOSPITALARIA\n");
		
		IColaGuardiaPacientes guardia = new ColaGuardiaPacientes(5);
		
		System.out.println(">>> FASE 1: REGISTRO DE PACIENTES");
		guardia.registrarPaciente("Juan Perez", 11222333, 3);
		guardia.registrarPaciente("Ana Gomez", 44555666, 1);
		guardia.registrarPaciente("Carlos Ruiz", 77888999, 2);
		guardia.registrarPaciente("Laura Diaz", 10101010, 1);
		
		guardia.listarPacientesPendientes();
		
		System.out.println(">>> FASE 2: AUDITORÍA DEL PRÓXIMO TURNO");
		Paciente proximo = guardia.mostrarPrimero();
		if (proximo != null) {
			System.out.println("Médico de guardia preparado para: " + proximo.nombre);
		}
		
		System.out.println("\n>>> FASE 3: ATENCIÓN EN CONSULTORIOS");
		while (guardia.hayPacientesPendientes()) {
			Paciente actual = guardia.atenderSiguiente();
			System.out.println("Atendiendo a: " + actual.nombre + " (Prioridad " + actual.prioridad + ")");
		}
		
		System.out.println("\n>>> FASE 4: VALIDACIÓN FINAL");
		guardia.listarPacientesPendientes();

	}

}
