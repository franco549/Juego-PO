package atencionDePacientes;

public interface IColaGuardiaPacientes {
	void registrarPaciente(String nombre, int dni, int prioridad);
	Paciente atenderSiguiente();
	Paciente mostrarPrimero();
	void listarPacientesPendientes();
	boolean hayPacientesPendientes();
}
