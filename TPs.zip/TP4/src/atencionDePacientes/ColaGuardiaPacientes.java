package atencionDePacientes;

public class ColaGuardiaPacientes implements IColaGuardiaPacientes{
	
	private Paciente[] cola;
	private int cantidad;
	
	public ColaGuardiaPacientes(int capacidadMaxima) {
		
		this.cola = new Paciente[capacidadMaxima];
		this.cantidad = 0;
	}
	
	public void registrarPaciente(String nombre, int dni, int prioridad) {
		if (cantidad < cola.length) {
			Paciente nuevo = new Paciente(nombre, dni, prioridad);
			int i = cantidad;
			
			while (i > 0 && cola[i - 1].prioridad > prioridad) {
				cola[i] = cola[i - 1];
				i--;
			}
			
			cola[i] = nuevo;
			cantidad++;
			
		} else {
			System.out.println("ALERTA: Guardia colapsada. No se pudo registrar a " + nombre);
		}
	}
	
	public Paciente atenderSiguiente() {
		Paciente pacienteAtendido = null;
		
		if (hayPacientesPendientes()) {
			pacienteAtendido = cola[0];
			
			for (int i = 0; i < cantidad - 1; i++) {
				cola[i] = cola[i + 1];
			}
			cantidad--;
		} else {
			System.out.println("INFO: No hay pacientes en espera en la guardia.");
		}
		
		return pacienteAtendido;
	}
	
	public Paciente mostrarPrimero() {
		Paciente primero = null;
		
		if (hayPacientesPendientes()) {
			primero = cola[0];
		} else {
			System.out.println("INFO: La guardia está vacía.");
		}
		
		return primero;
	}
	
	public void listarPacientesPendientes() {
		System.out.println("\n--- PANTALLA DE SALA DE ESPERA ---");
		if (hayPacientesPendientes()) {
			for (int i = 0; i < cantidad; i++) {
				System.out.println((i + 1) + ". " + cola[i].obtenerDatos());
			}
		} else {
			System.out.println("Sala de espera vacía.");
		}
		System.out.println("----------------------------------\n");
	}
	
	public boolean hayPacientesPendientes() {
		return cantidad > 0;
	}
}
