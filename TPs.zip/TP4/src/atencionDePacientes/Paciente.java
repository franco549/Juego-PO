package atencionDePacientes;

public class Paciente {
	
	String nombre;
	int dni;
	int prioridad;
	
	public Paciente(String nombre, int dni, int prioridad) {
		this.nombre = nombre;
		this.dni = dni;
		this.prioridad = prioridad;
	}
	
	public String obtenerDatos() {
		return nombre + " (DNI: " + dni + ") - Prioridad: " + prioridad;
	}
}
