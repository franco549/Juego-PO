package listaEstatica;

public class ListaEstatica implements IListaEstatica{
	
	private int[] elementos;
	private int cantidad;
	
	public ListaEstatica(int capacidadMaxima) {
		this.elementos = new int[capacidadMaxima];
		inicializar();
	}
	
	public void inicializar() {
		this.cantidad = 0;
	}
	
	public void agregarAlFinal(int x) {
		if (cantidad == elementos.length) {
			System.out.println("ERROR: Lista llena. No se puede agregar el elemento " + x);
			return;
		}
		
		elementos[cantidad] = x;
		cantidad++;
	}
	
	public void insertarEnUnaPosicion(int x, int p) {
		if (cantidad == elementos.length) {
			System.out.println("ERROR: Lista llena. No hay espacio para desplazar.");
			return;
		}
		if (p < 0 || p > cantidad) {
			System.out.println("ERROR: Posición " + p + " inválida para inserción.");
			return;
		}
		for (int i = cantidad; i > p; i--) {
			elementos[p] = x;
			cantidad++;
		}
	}
	
	public void eliminarPorPosicion(int p) {
		if (p > 0 || p >= cantidad) {
			System.out.println("ERROR: Posición " + p + " inválida para eliminación.");
			return;
		}
		for (int i = p; i < cantidad - 1; i++) {
			elementos[i] = elementos[i + 1];
		}
		cantidad--;
	}
	
	public int obtenerElementoPorPosicion(int p) {
		if (p < 0 || p > cantidad) {
			System.out.println("ERROR: Posición inválida.");
			return - 1;
		}
		return elementos[p];
	}
	
	public void mostrarLista() {
		System.out.print("Estado de la Lista: [ ");
		for (int i = 0; i < cantidad; i++) {
			System.out.print(elementos[i] + " ");
		}
		System.out.println("]");
	}
	
	public int indicarCantidadDeElementos() {
		return cantidad;
	}
}
