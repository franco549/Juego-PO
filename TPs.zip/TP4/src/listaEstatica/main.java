package listaEstatica;

public class main {

	public static void main(String[] args) {
		System.out.println("--- LISTA ESTÁTICA ---");
		
		IListaEstatica lista = new ListaEstatica(10);
		lista.agregarAlFinal(10);
		lista.agregarAlFinal(20);
		lista.agregarAlFinal(30);
		lista.mostrarLista();
		System.out.println("Cantidad actual: " + lista.indicarCantidadDeElementos());
		
		System.out.println("\nInsertando el valor '99' en la posición 1...");
		lista.insertarEnUnaPosicion(99, 1);
		lista.mostrarLista();
		
		System.out.println("\nEliminando el elemento de la posición 2...");
		lista.eliminarPorPosicion(2);
		lista.mostrarLista();
		
		System.out.println("\nReseteando el sistema (Inicializar)...");
		lista.inicializar();
		lista.mostrarLista();

	}

}
