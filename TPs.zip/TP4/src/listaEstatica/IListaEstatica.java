package listaEstatica;

public interface IListaEstatica {
	void inicializar();
	void agregarAlFinal(int x);
	void insertarEnUnaPosicion(int x, int p);
	void eliminarPorPosicion(int p);
	int obtenerElementoPorPosicion(int p);
	void mostrarLista();
	int indicarCantidadDeElementos();
}
