package diccionario;

public class Diccionario implements IDiccionario {
	
	// ESTRUCTURA INTERNA: Dos arreglos paralelos. 
	// Lo que está en claves[2] le pertenece a valores[2].
	private int[] claves;
	private String[] valores;
	private int cantidad;
	
	public Diccionario(int capacidadMaxima) {
		this.claves = new int[capacidadMaxima];
		this.valores = new String[capacidadMaxima];
		this.cantidad = 0;
	}

	// MÉTODOS AUXILIARES PRIVADOS (Buenas prácticas)
	// Este método centraliza la búsqueda para no repetir el bucle 'while' en put, get y remove.
	private int obtenerIndice(int clave) {
		int indiceBuscado = -1; // SESE: -1 significa "No encontrado"
		int i = 0;
		
		// Búsqueda lineal O(n). Sin 'break'.
		while (i < cantidad && indiceBuscado == -1) {
			if (claves[i] == clave) {
				indiceBuscado = i;
			}
			i++;
		}
		return indiceBuscado;
	}

	@Override
	public boolean containsKey(int clave) {
		// Reutilizamos nuestro método de búsqueda. Si es distinto de -1, existe.
		return obtenerIndice(clave) != -1;
	}

	@Override
	public void put(int clave, String valor) {
		int indice = obtenerIndice(clave);
		
		// LÓGICA DE DIAPOSITIVA 14: "recorrer buscando la clave; si existe actualizar..."
		if (indice != -1) {
			valores[indice] = valor; // Modificamos el valor existente. La clave queda igual.
			System.out.println("Actualizado: Clave " + clave + " ahora es '" + valor + "'.");
		} 
		// "... si no, insertar al final"
		else {
			if (cantidad < claves.length) {
				claves[cantidad] = clave;
				valores[cantidad] = valor;
				cantidad++;
				System.out.println("Insertado: [" + clave + "] -> " + valor);
			} else {
				System.out.println("Error: Diccionario lleno. No se puede insertar " + clave);
			}
		}
	}

	@Override
	public String get(int clave) {
		String valorRetorno = null; // SESE: Valor por defecto si no existe
		int indice = obtenerIndice(clave);
		
		if (indice != -1) {
			valorRetorno = valores[indice];
		}
		
		return valorRetorno;
	}

	@Override
	public void remove(int clave) {
		int indice = obtenerIndice(clave);
		
		if (indice != -1) {
			// LÓGICA DE DIAPOSITIVA 14: "copiar último elemento al hueco, decrementar size"
			// Esta es una optimización brutal O(1) para arreglos NO ORDENADOS. 
			// En lugar de desplazar todos los elementos con un 'for', tapamos el hueco con el último.
			claves[indice] = claves[cantidad - 1];
			valores[indice] = valores[cantidad - 1];
			
			// Limpiamos la última posición por seguridad (evita retener memoria basura)
			valores[cantidad - 1] = null; 
			
			cantidad--;
			System.out.println("Eliminado: Se borró la clave " + clave + " del sistema.");
		} else {
			System.out.println("Error: La clave " + clave + " no existe. No se puede eliminar.");
		}
	}

	@Override
	public void mostrarDiccionario() {
		System.out.println("\n--- ESTADO DEL DICCIONARIO ---");
		if (cantidad == 0) {
			System.out.println("El diccionario está vacío.");
		} else {
			for (int i = 0; i < cantidad; i++) {
				System.out.println("Clave: " + claves[i] + " | Valor: " + valores[i]);
			}
		}
		System.out.println("------------------------------\n");
	}
}