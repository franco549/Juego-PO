package diccionario;

public class Main {

	public static void main(String[] args) {
		
		// Instanciamos el TDA contra la Interfaz
		IDiccionario inventario = new Diccionario(5);
		
		System.out.println(">>> 1. INSERTANDO PARES CLAVE-VALOR");
		inventario.put(101, "Teclado Mecánico");
		inventario.put(102, "Mouse Óptico");
		inventario.put(103, "Monitor 24 Pulgadas");
		inventario.mostrarDiccionario();
		
		System.out.println(">>> 2. MODIFICANDO VALOR (Clave repetida)");
		// Al insertar la misma clave (102), no se duplica, debe REEMPLAZAR el valor.
		inventario.put(102, "Mouse Inalámbrico");
		inventario.mostrarDiccionario();
		
		System.out.println(">>> 3. BUSCANDO VALOR POR CLAVE (get)");
		int claveABuscar = 101;
		if (inventario.containsKey(claveABuscar)) {
			String producto = inventario.get(claveABuscar);
			System.out.println("Resultado de búsqueda [" + claveABuscar + "]: " + producto);
		}
		
		System.out.println("\n>>> 4. ELIMINANDO UNA CLAVE");
		inventario.remove(101); // Borramos el teclado
		inventario.mostrarDiccionario(); 
		// Fíjate en la consola cómo el "Monitor" (que era el último) tapó el hueco del "Teclado".
	}
}