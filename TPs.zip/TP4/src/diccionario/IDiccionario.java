package diccionario;

public interface IDiccionario {
	
	// OPERACIONES OFICIALES DEL TDA DICCIONARIO (Según Diapositiva 5)
	
	// 'put' cumple doble función: inserta si la clave no existe, o modifica si ya existe.
	void put(int clave, String valor);
	
	// 'get' devuelve el valor asociado a la clave (o null si no existe).
	String get(int clave);
	
	// 'remove' elimina el par clave-valor del sistema.
	void remove(int clave);
	
	// 'containsKey' verifica la existencia de una clave sin devolver su valor.
	boolean containsKey(int clave);
	
	// OPERACIÓN AUXILIAR (Solicitada por la consigna)
	void mostrarDiccionario();
}