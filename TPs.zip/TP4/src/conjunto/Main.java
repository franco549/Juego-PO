package conjunto;

public class Main {

	public static void main(String[] args) {
		System.out.println("--- MOTOR DE ÁLGEBRA DE CONJUNTOS ---");
		
		IConjunto conjuntoA = new Conjunto(10);
		IConjunto conjuntoB = new Conjunto(10);
		
		System.out.println("\n>>> CARGANDO CONJUNTO A:");
		conjuntoA.agregarElemento(1);
		conjuntoA.agregarElemento(2);
		conjuntoA.agregarElemento(3);
		conjuntoA.agregarElemento(2);
		
		System.out.print("Conjunto A = ");
		conjuntoA.mostrarConjunto();
		
		System.out.println("\n>>> CARGANDO CONJUNTO B:");
		conjuntoB.agregarElemento(3);
		conjuntoB.agregarElemento(4);
		conjuntoB.agregarElemento(5);
		
		System.out.print("Conjunto B = ");
		conjuntoB.mostrarConjunto();
		
		System.out.println("\n--- OPERACIONES MATEMÁTICAS ---");
		
		System.out.print("Unión (A U B) = ");
		IConjunto resultadoUnion = conjuntoA.union(conjuntoB);
		resultadoUnion.mostrarConjunto();
		
		System.out.print("Intersección (A ∩ B) = ");
		IConjunto resultadoInterseccion = conjuntoA.interseccion(conjuntoB);
		resultadoInterseccion.mostrarConjunto();
		
		System.out.print("Diferencia (A - B) = ");
		IConjunto resultadoDiferencia = conjuntoA.diferencia(conjuntoB);
		resultadoDiferencia.mostrarConjunto();
		
		System.out.print("Diferencia (B - A) = ");
		IConjunto diferenciaInversa = conjuntoB.diferencia(conjuntoA);
		diferenciaInversa.mostrarConjunto();
		
	}

}
