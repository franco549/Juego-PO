package conjunto;

public interface IConjunto {
	void agregarElemento(int elemento);
	void eliminarElemento(int elemento);
	boolean pertenece(int elemento);
	IConjunto union(IConjunto otroConjunto);
	IConjunto interseccion(IConjunto otroConjunto);
	IConjunto diferencia(IConjunto otroConjunto);
	int obtenerCantidad();
	int obtenerElemento(int indice);
	void mostrarConjunto();
}
