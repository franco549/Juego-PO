package conjunto;

public class Conjunto implements IConjunto{
	
	private int[] elementos;
	private int cantidad;
	
	public Conjunto(int capacidadMaxima) {
		this.elementos = new int[capacidadMaxima];
		this.cantidad = 0;
	}
	
	public boolean pertenece(int elemento) {
		boolean encontrado = false;
		int i = 0;
		
		while (i < cantidad && !encontrado) {
			if(elementos[i] == elemento) {
				encontrado = true;
			}
			i++;
		}
		
		return encontrado;
	}
	
	public void agregarElemento(int elemento) {
		if (cantidad < elementos.length) {
			if (!pertenece(elemento)) {
				elementos[cantidad] = elemento;
				cantidad++;
			} else {
				System.out.println("Rechazado: El elemento " + elemento + " ya existe en el conjunto.");
			}
		} else {
			System.out.println("Error: Capacidad máxima del conjunto alcanzada.");
		}
			}
	
	public void eliminarElemento(int elemento) {
		int indiceAEliminar = -1;
		int i = 0;
		
		while (i < cantidad && indiceAEliminar == - 1) {
			if (elementos[i] == elemento) {
				indiceAEliminar = i;
			}
			i++;
		}
		
		if (indiceAEliminar != -1) {
			for (int j = indiceAEliminar; j < cantidad - 1; j++) {
				elementos[j] = elementos[j + 1];
			}
			cantidad--;
		} else {
			System.out.println("Aviso: El elemento " + elemento + " no pertenece al conjunto, no se puede eliminar.");
		}
	}
	
	public IConjunto union(IConjunto otroConjunto) {
		int capacidadTotal = this.cantidad + otroConjunto.obtenerCantidad();
		IConjunto conjuntoUnion = new Conjunto(capacidadTotal);
		
		for (int i = 0; i < this.cantidad; i++) {
			conjuntoUnion.agregarElemento(this.elementos[i]);
		}
		
		for (int i = 0; i < otroConjunto.obtenerCantidad(); i++) {
			conjuntoUnion.agregarElemento(otroConjunto.obtenerElemento(i));
		}
		
		return conjuntoUnion;
	}
	
	public IConjunto interseccion(IConjunto otroConjunto) {
		IConjunto conjuntoInterseccion = new Conjunto(this.cantidad);
		
		for (int i = 0; i < this.cantidad; i++) {
			if (otroConjunto.pertenece(this.elementos[i])) {
				conjuntoInterseccion.agregarElemento(this.elementos[i]);
			}
		}
		
		return conjuntoInterseccion;
	}
	
	public IConjunto diferencia(IConjunto otroConjunto) {
		IConjunto conjuntoDiferencia = new Conjunto(this.cantidad);
		
		for (int i = 0; i < this.cantidad; i++) {
			if (!otroConjunto.pertenece(this.elementos[i])) {
				conjuntoDiferencia.agregarElemento(this.elementos[i]);
			}
		}
		
		return conjuntoDiferencia;
	}
	
	public void mostrarConjunto() {
		System.out.print("{ ");
		for (int i = 0; i < cantidad; i++) {
			System.out.print(elementos[i]);
			if (i < cantidad - 1) {
				System.out.print(", ");
			}
		}
		System.out.println(" }");
	}
	
	public int obtenerCantidad() {
		return cantidad;
	}
	
	public int obtenerElemento(int indice) {
		int valorRetorno = -1;
		if (indice >= 0 && indice < cantidad) {
			valorRetorno = elementos[indice];
		}
		return valorRetorno;
	}
}
