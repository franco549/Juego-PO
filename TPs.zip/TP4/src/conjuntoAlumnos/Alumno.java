package conjuntoAlumnos;

public class Alumno {
	
	// ENCAPSULAMIENTO: Al declarar los atributos como 'private', bloqueamos el 
	// acceso directo desde otras clases. Nadie puede hacer 'alumno.legajo = 999'.
	// Esto protege la integridad de los datos (lo convierte en un objeto inmutable).
	private String nombre;
	private int legajo;

	// CONSTRUCTOR: Es el método que "da vida" al objeto. 
	// Se ejecuta automáticamente cuando usamos la palabra 'new'.
	public Alumno(String nombre, int legajo) {
		this.nombre = nombre;
		this.legajo = legajo;
	}
	
	// GETTERS (Métodos de acceso): Como los atributos son privados, esta es la 
	// única ventana "pública" que le damos al sistema para leer los datos.
	public String getNombre() {
		return nombre;
	}

	public int getLegajo() {
		return legajo;
	}
	
	// MÉTODO UTILITARIO: Nos facilita imprimir los datos del alumno sin tener
	// que concatenar cadenas de texto cada vez que queramos mostrarlo.
	public String obtenerDatos() {
		return nombre + " (Legajo: " + legajo + ")";
	}
}