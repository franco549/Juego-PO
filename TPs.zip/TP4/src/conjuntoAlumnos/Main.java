package conjuntoAlumnos;

public class Main {

	public static void main(String[] args) {
		
		// INSTANCIACIÓN POLIMÓRFICA: 
		// El tipo de dato es la Interfaz (IConjuntoAlumnos), 
		// pero la memoria física se crea con la clase concreta (ConjuntoAlumnos).
		IConjuntoAlumnos programacion = new ConjuntoAlumnos(10);
		IConjuntoAlumnos baseDeDatos = new ConjuntoAlumnos(10);
		
		System.out.println("--- INSCRIPCIONES EN SISTEMA ---");
		
		// Llenamos el conjunto de Programación
		programacion.agregarAlumno("Juan", 101);
		programacion.agregarAlumno("Maria", 102);
		programacion.agregarAlumno("Carlos", 103);
		
		// Llenamos el conjunto de Base de Datos.
		// Notar que Maria y Carlos se inscriben en ambas materias.
		baseDeDatos.agregarAlumno("Maria", 102);
		baseDeDatos.agregarAlumno("Carlos", 103);
		baseDeDatos.agregarAlumno("Ana", 104);
		
		System.out.println("\n--- RESULTADOS DEL ANÁLISIS ---");
		
		// CASO 1: Alumnos que cursan ambas materias (Intersección A ∩ B)
		// Esperado: Maria (102) y Carlos (103)
		System.out.println("\n1. Cursan AMBAS materias (Intersección):");
		IConjuntoAlumnos ambas = programacion.interseccion(baseDeDatos);
		ambas.mostrarConjunto();
		
		// CASO 2: Alumnos que cursan SOLO Programación (Diferencia A - B)
		// Esperado: Juan (101). Maria y Carlos se restan porque también hacen BD.
		System.out.println("\n2. Cursan SOLO Programación (Diferencia):");
		IConjuntoAlumnos soloProg = programacion.diferencia(baseDeDatos);
		soloProg.mostrarConjunto();
		
		// CASO 3: Alumnos que cursan AL MENOS UNA materia (Unión A U B)
		// Esperado: Juan, Maria, Carlos, Ana (Sin repetir a Maria ni Carlos).
		System.out.println("\n3. Cursan AL MENOS UNA materia (Unión):");
		IConjuntoAlumnos alMenosUna = programacion.union(baseDeDatos);
		alMenosUna.mostrarConjunto();
	}
}