package conjuntoAlumnos;

public class ConjuntoAlumnos implements IConjuntoAlumnos {
	
	// ESTRUCTURA INTERNA: Un arreglo estático para guardar los objetos y 
	// un contador ('cantidad') para saber cuántos cajones están realmente ocupados.
	private Alumno[] alumnos;
	private int cantidad;
	
	public ConjuntoAlumnos(int capacidadMaxima) {
		this.cantidad = 0;
		// Aquí solo creamos la "caja" de N espacios, pero los espacios adentro
		// tienen valor 'null'. Aún no hay alumnos reales.
		this.alumnos = new Alumno[capacidadMaxima];
	}
	
	@Override
	public boolean pertenece(int legajo) {
		boolean esta = false; // Variable de estado (Bandera)
		int i = 0;
		
		// BÚSQUEDA LINEAL: Se detiene si recorre todo (i < cantidad) 
		// O si encuentra al alumno (!esta). Esto evita usar 'break'.
		while (i < cantidad && !esta) {
			// Usamos el Getter getLegajo() porque el atributo original es private
			if (alumnos[i].getLegajo() == legajo) {
				esta = true;
			}
			i++;
		}
		return esta; // SESE: Único punto de salida
	}
	
	@Override
	public void agregarAlumno(String nombre, int legajo) {
		// 1. Validamos que haya espacio en la memoria (en el arreglo)
		if (cantidad < alumnos.length) {
			
			// 2. REGLA DEL TDA CONJUNTO: No se permiten duplicados.
			// Reutilizamos el método 'pertenece' para delegar el trabajo de búsqueda.
			if (!pertenece(legajo)) {
				// 3. INSTANCIACIÓN: Usamos 'new' para crear el objeto físico en la memoria
				// y lo guardamos en la primera posición libre (indicada por 'cantidad').
				alumnos[cantidad] = new Alumno(nombre, legajo);
				cantidad++; // Aumentamos el contador de ocupación
			} else {
				System.out.println("Rechazado: El legajo " + legajo + " ya pertenece al conjunto.");
			}
			
		} else {
			System.out.println("Error: Capacidad máxima del conjunto alcanzada.");
		}
	}
	
	@Override
	public void eliminarAlumno(int legajo) {
		int indiceAEliminar = -1; // -1 indica que "aún no lo encontramos"
		int i = 0;
		
		// FASE 1: BÚSQUEDA DEL ÍNDICE
		// Recorremos el arreglo hasta encontrar la posición exacta del alumno.
		while (i < cantidad && indiceAEliminar == -1) {
			if (alumnos[i].getLegajo() == legajo) {
				indiceAEliminar = i; // Guardamos dónde está
			}
			i++;
		}
		
		// FASE 2: DESPLAZAMIENTO (SHIFT LEFT)
		if (indiceAEliminar != -1) {
			// Si lo encontramos, movemos todos los elementos que están a la derecha 
			// un paso hacia la izquierda, aplastando y borrando al alumno eliminado.
			for (int j = indiceAEliminar; j < cantidad - 1; j++) {
				alumnos[j] = alumnos[j + 1]; 
			}
			cantidad--; // Achicamos el tamaño lógico del conjunto
		} else {
			System.out.println("Error: El alumno no se encuentra en el conjunto.");
		}
	}
	
	@Override
	public IConjuntoAlumnos interseccion(IConjuntoAlumnos otroConjunto) {
		// La intersección crea un conjunto NUEVO. En el peor caso, será del mismo tamaño.
		IConjuntoAlumnos resultado = new ConjuntoAlumnos(this.cantidad);
		
		for (int i = 0; i < this.cantidad; i++) {
			// LÓGICA: Si el alumno de MI conjunto, también 'pertenece' al OTRO conjunto...
			if (otroConjunto.pertenece(this.alumnos[i].getLegajo())) {
				// ... entonces lo agrego al conjunto resultado.
				resultado.agregarAlumno(this.alumnos[i].getNombre(), this.alumnos[i].getLegajo());
			}
		}
		return resultado;
	}
	
	@Override
	public IConjuntoAlumnos union(IConjuntoAlumnos otroConjunto) {
		// La capacidad máxima teórica es sumar el tamaño de ambos conjuntos.
		int capacidadTotal = this.cantidad + otroConjunto.obtenerCantidad();
		IConjuntoAlumnos resultado = new ConjuntoAlumnos(capacidadTotal);
		
		// PASO 1: Copiamos todos los elementos de MI conjunto (this) al resultado.
		for (int i = 0; i < this.cantidad; i++) {
			resultado.agregarAlumno(this.alumnos[i].getNombre(), this.alumnos[i].getLegajo());
		}
		
		// PASO 2: Copiamos los elementos del OTRO conjunto.
		for (int i = 0; i < otroConjunto.obtenerCantidad(); i++) {
			Alumno a = otroConjunto.obtenerAlumno(i);
			// MAGIA DEL CÓDIGO: Al llamar a 'agregarAlumno()', este método internamente 
			// ya verifica con 'pertenece()' si el legajo existe. Por lo tanto, los alumnos
			// que cursan ambas materias serán rechazados y NO se duplicarán.
			resultado.agregarAlumno(a.getNombre(), a.getLegajo());
		}
		
		return resultado;
	}

	@Override
	public IConjuntoAlumnos diferencia(IConjuntoAlumnos otroConjunto) {
		IConjuntoAlumnos resultado = new ConjuntoAlumnos(this.cantidad);
		
		for (int i = 0; i < this.cantidad; i++) {
			// LÓGICA: A diferencia (A - B) significa todos los de A que NO están en B.
			if (!otroConjunto.pertenece(this.alumnos[i].getLegajo())) {
				resultado.agregarAlumno(this.alumnos[i].getNombre(), this.alumnos[i].getLegajo());
			}
		}
		return resultado;
	}

	@Override
	public void mostrarConjunto() {
		System.out.println("{ ");
		// Recorremos solo hasta 'cantidad', no hasta 'alumnos.length', 
		// para evitar imprimir los espacios que están en 'null'.
		for (int i = 0; i < cantidad; i++) {
			System.out.println("  " + alumnos[i].obtenerDatos());
		}
		System.out.println("}");
	}

	// GETTERS DEL CONJUNTO (Para interactuar con la Interfaz)
	@Override
	public int obtenerCantidad() {
		return cantidad;
	}

	@Override
	public Alumno obtenerAlumno(int indice) {
		Alumno valorRetorno = null; // SESE: Inicializamos la variable a devolver
		
		// Validamos que el índice no se salga de los límites reales del arreglo
		if (indice >= 0 && indice < cantidad) {
			valorRetorno = alumnos[indice];
		}
		return valorRetorno; // SESE: Un solo retorno al final
	}
}