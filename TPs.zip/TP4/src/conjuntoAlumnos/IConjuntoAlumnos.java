package conjuntoAlumnos;

public interface IConjuntoAlumnos {
	
	// OPERACIONES DE MUTACIÓN Y ESTADO
	void agregarAlumno(String alumno, int legajo);
	void eliminarAlumno(int legajo);
	boolean pertenece(int legajo);
	void mostrarConjunto();
	
	// OPERACIONES DEL ÁLGEBRA DE CONJUNTOS
	// Retornan 'IConjuntoAlumnos' en lugar de la clase concreta para mantener 
	// el Polimorfismo. Así, nuestro sistema no depende de los arreglos estáticos.
	IConjuntoAlumnos interseccion(IConjuntoAlumnos otroConjunto);
	IConjuntoAlumnos diferencia(IConjuntoAlumnos otroConjunto);
	IConjuntoAlumnos union(IConjuntoAlumnos otroConjunto);
	
	// MÉTODOS DE LECTURA (Básicos para la interacción entre dos conjuntos)
	// Como la clase concreta encapsula su arreglo (private Alumno[]), un conjunto A 
	// no puede leer el arreglo del conjunto B directamente. Necesita estos métodos.
	int obtenerCantidad();
	Alumno obtenerAlumno(int indice);
}