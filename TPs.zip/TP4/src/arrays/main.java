package arrays;

import java.util.Scanner; // 1. Importación de la librería

public class main {

	public static void main(String[] args) {
		// 2. Instanciación centralizada del recurso I/O
		Scanner scanner = new Scanner(System.in);
		
		// 3. Inyección de la dependencia hacia los métodos
		arraysCargaYRecorrido(scanner);
		arraysBusquedaDeUnElemento(scanner);
		
		// 4. Liberación de memoria y cierre del flujo a nivel global
		scanner.close(); 
	}
	
	// EJERCICIO 1
	public static void arraysCargaYRecorrido(Scanner scanner) { // Recibe el objeto por referencia
		System.out.println("--- EJERCICIO 1: Carga de Datos ---");
		
		// Asignación de capacidad para 10 enteros vacíos (inicializados en 0 por defecto)
		int[] numeros = new int[10]; 
		
		// Fase de Carga Dinámica O(n)
		for (int i = 0; i < numeros.length; i++) {
			System.out.print("Ingrese el valor entero para el índice [" + i + "]: ");
			numeros[i] = scanner.nextInt(); // Captura de teclado
		}
		
		// Fase de Procesamiento
		int suma = 0;
		int mayor = numeros[0];
		int menor = numeros[0];
		
		for (int i = 0; i < numeros.length; i++) {
			suma = suma + numeros[i];
			if (numeros[i] > mayor) {
				mayor = numeros[i];
			}
			if (numeros[i] < menor) {
				menor = numeros[i];
			}
		}
		
		System.out.println("[SUMA TOTAL DE NUMEROS: " + suma + "]");
		System.out.println("[MAYOR NUMERO: " + mayor + "]");
		System.out.println("[MENOR NUMERO: " + menor + "]\n");
	}
	
	// EJERCICIO 2
	public static void arraysBusquedaDeUnElemento(Scanner scanner) { // Recibe el objeto por referencia
		System.out.println("--- EJERCICIO 2: Búsqueda Secuencial ---");
		
		int[] numeros = {23, 20, 12, 15, 64, 23, 90, 22, 41, 20, 25, 19, 20, 13, 32};
		
		// Captura de teclado para el objetivo de búsqueda
		System.out.print("Ingrese el número entero a buscar en el sistema: ");
		int numeroABuscar = scanner.nextInt(); 
		
		int repeticiones = 0;
		// Corrección Crítica: El tamaño debe ser igual a la longitud máxima posible, no "14" estático.
		int[] posicionesEncontrado = new int[numeros.length]; 
		String stringPosicionesEncontrado = "";
		int j = 0;
		
		// Búsqueda dinámica basada en .length
		for (int i = 0; i < numeros.length; i++) {
			if (numeros[i] == numeroABuscar) {
				repeticiones++;
				posicionesEncontrado[j] = i;
				j++;
			}
		}
		
		// Formateo del string de salida
		for (int k = 0; k < repeticiones; k++) {
			stringPosicionesEncontrado += posicionesEncontrado[k] + (k < repeticiones - 1 ? ", " : "");
		}
		
		// Evaluación de Resultados
		if (repeticiones > 1) {
			System.out.println("[Se encontró el número [" + numeroABuscar + "] un total de (" + repeticiones + ") veces, en las posiciones (" + stringPosicionesEncontrado + ")]");
		}
		else if (repeticiones == 1) {
			System.out.println("[Se encontró el número [" + numeroABuscar + "] un total de (" + repeticiones + ") vez, en la posición (" + stringPosicionesEncontrado + ")]");
		}
		else {
			System.out.println("[No se encontró el número [" + numeroABuscar + "]]");
		}
	}
}
