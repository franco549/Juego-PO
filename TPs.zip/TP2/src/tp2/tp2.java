package tp2;

public class tp2 {

	public static void main(String[] args) {
		//mostrarNumerosDel1Al10();
		//mostrarNumerosParesDel1Al20();
		//sumarNumerosDel1AlN();
		//contarCuantosNumerosImparesHayEntre1Y50();
		//mostrarNumerosHastaQueUnoSeaMayorA100();
		//determinarSiUnNumeroEsPrimo();
		//determinarSiUnNumeroEsParOImpar();
		//dadoUnNumeroIndicarSiEsPositivoNegativoO0();
		//simularUnMenuConDoWhile();
		//encontrarElMayorDe3Numeros();
		}
	
	// 1
	static void mostrarNumerosDel1Al10() {
		
		for (int i = 1; i <= 10; i++) {
			System.out.println(i);
		}
	}
	
	// 2
	static void mostrarNumerosParesDel1Al20() {
		
		for (int i = 2; i <= 20; i = i +2) {
			System.out.println(i);
		}
	}
	
	// 3
	static void sumarNumerosDel1AlN() {
		
		int n = 12;
		int suma = 0;
		for (int i = 1; i <= n; i++) {
			suma = suma + i;
		}
		System.out.println(suma);
	}
	
	// 4
	static void contarCuantosNumerosImparesHayEntre1Y50() {
		
		int numerosImpares = 0;
		for (int i = 1; i <= 50; i++) {
			if (i % 2 != 0) {
				numerosImpares++;
			}
		}
		System.out.println(numerosImpares);
	}
	
	// 5
	static void mostrarNumerosHastaQueUnoSeaMayorA100() {
		
		int i = 1;
		while (i <= 100) {
			System.out.println(i);
			i++;
		}
	}
	
	// 6
	static void determinarSiUnNumeroEsPrimo() {
		
		int n = 19;
		boolean esPrimo = true;
		if (n <= 1) {
			esPrimo = false;
		}
		for (int i = 2; i < n; i++) {
			if (n % i == 0) {
				esPrimo = false;
			}
		}
		if (esPrimo == true) {
			System.out.println("Número primo.");
		}
		else {
			System.out.println("Número no primo.");
		}
	}
	
	// 7
	static void determinarSiUnNumeroEsParOImpar() {
		
		int n = 5;
		if (n % 2 == 0) {
			System.out.println("Número par.");
		}
		else {
			System.out.println("Número impar.");
		}
	}
	
	// 8
	static void dadoUnNumeroIndicarSiEsPositivoNegativoO0() {
		
		int n = -3;
		if (n > 0) {
			System.out.println("Número positivo.");
		}
		else if (n < 0) {
			System.out.println("Número negativo.");
		}
		else {
			System.out.println("Cero.");
		}
	}
	
	// 9
	static void simularUnMenuConDoWhile() {
		
		int opcion;
		do {
		    System.out.println("--- MENÚ PRINCIPAL ---");
		    System.out.println("1. Iniciar");
		    System.out.println("2. Opciones");
		    System.out.println("3. Salir");
		    opcion = 3; 
		    switch (opcion) {
		        case 1:
		            System.out.println("Iniciando...");
		            break;
		        case 2:
		            System.out.println("Abriendo opciones...");
		            break;
		        case 3:
		            System.out.println("Saliendo del programa.");
		            break;
		        default:
		            System.out.println("Opción incorrecta, intenta de nuevo.");
		    }
		} while (opcion != 3);
		
	}
	
	// 10
	static void encontrarElMayorDe3Numeros() {
		
		int n1 = 2;
		int n2 = 5;
		int n3 = 4;
		if (n1 > n2 && n1 > n3) {
			System.out.println("El mayor número es " + n1 + ".");
		}
		else if (n2 > n1 && n2 > n3) {
			System.out.println("El mayor número es " + n2 + ".");
		}
		else if (n3 > n1 && n3 > n2) {
			System.out.println("El mayor número es " + n3 + ".");
		}
		else {
			System.out.println("Dos o más números son iguales entre sí.");
		}
	}
	
	// SIGUIENTES TEMAS NO VISTOS
	
}
